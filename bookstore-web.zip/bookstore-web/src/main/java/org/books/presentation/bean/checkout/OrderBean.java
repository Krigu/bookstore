package org.books.presentation.bean.checkout;


/*import org.books.application.Bookstore;
import org.books.application.BookstoreException;*/
import org.books.application.ShoppingCart;
import org.books.data.dto.OrderDTO;
import org.books.data.dto.OrderItemDTO;
import org.books.util.MessageFactory;

import javax.enterprise.context.SessionScoped;
import javax.inject.Inject;
import javax.inject.Named;
import java.io.Serializable;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.EJB;
import org.books.application.OrderService;
import org.books.application.exception.BookNotFoundException;
import org.books.application.exception.CustomerNotFoundException;
import org.books.application.exception.PaymentFailedException;

@SessionScoped
@Named("orderBean")
public class OrderBean implements Serializable {

    //@Inject
    //private Bookstore bookstore;
    @EJB
    private OrderService orderService;

    @Inject
    private ShoppingCart shoppingCart;

    private OrderDTO order;

    /**
     *
     * @param customerNr
     * @param orderItems
     * @return
     */
    public String doSubmitOrder(String customerNr, List<OrderItemDTO> orderItems) {

        /*try {
            this.order = bookstore.placeOrder(email, orderItems);
        } catch (BookstoreException e) {
            MessageFactory.error(e.getMessage());
            return null;
        }*/
        try {
            //TODO
            this.order = orderService.placeOrder(customerNr, orderItems);
        } catch (CustomerNotFoundException e) {
            MessageFactory.error(e.getMessage());
            return null;
        } catch (BookNotFoundException ex) {
            Logger.getLogger(OrderBean.class.getName()).log(Level.SEVERE, null, ex);
        } catch (PaymentFailedException ex) {
            Logger.getLogger(OrderBean.class.getName()).log(Level.SEVERE, null, ex);
        }

        clearCart();

        return "/user/orderConfirmation?faces-redirect=true&menuId=2";
    }

    private void clearCart() {
        shoppingCart.getItems().clear();
    }

    public OrderDTO getOrder() {
        return order;
    }

    public void setOrder(OrderDTO order) {
        this.order = order;
    }
}
