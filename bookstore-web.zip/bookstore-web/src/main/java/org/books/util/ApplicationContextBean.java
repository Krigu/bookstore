package org.books.util;

import java.math.BigDecimal;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.enterprise.context.ApplicationScoped;
import org.books.application.CatalogService;
import org.books.application.exception.BookAlreadyExistsException;
import org.books.data.dto.BookDTO;
import org.books.data.entity.Book;
import org.books.persistence.XmlParser;

/**
 *
 * @author tjd
 */
@ApplicationScoped
public class ApplicationContextBean {

    private static final Logger LOGGER = Logger.getLogger(ApplicationContextBean.class.getName());
    private static final String CATALOG_DATA = "/data/catalog.xml";

    @EJB
    private CatalogService catalogService;

    @PostConstruct
    public void init() {
        LOGGER.log(Level.INFO, "TOFO init catalog");
        //BookDTO book1 = new BookDTO("Antonio Goncalves", Book.Binding.Paperback, "143024626X", 608, new BigDecimal(49.99), 2013, "Apress", "Beginning Java EE 7 (Expert Voice in Java)");
        //addBookDTO(book1);
        for (BookDTO book : XmlParser.parse(CATALOG_DATA, BookDTO.class)) {
            addBookDTO(book);
        }
    }

    private void addBookDTO(BookDTO book) {
        try {
            catalogService.addBook(book);
        } catch (BookAlreadyExistsException ex) {
            LOGGER.log(Level.WARNING, "Book already exist", ex);
        }
    }
}